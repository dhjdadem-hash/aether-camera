package app.aether.camera

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun Context.glass(radiusDp: Int = 24, fill: Int = 0x33FFFFFF, stroke: Int = 0x66FFFFFF) =
    GradientDrawable().apply {
        cornerRadius = dp(radiusDp).toFloat()
        setColor(fill)
        setStroke(dp(1), stroke)
    }

fun Context.glassButton(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
    text = label
    setTextColor(Color.WHITE)
    textSize = 14f
    gravity = Gravity.CENTER
    minWidth = dp(44)
    minHeight = dp(44)
    setPadding(dp(12), dp(6), dp(12), dp(6))
    background = glass(22)
    setOnClickListener { onClick() }
}

fun lp(w: Int = WRAP, h: Int = WRAP, m: Int = 0) =
    LinearLayout.LayoutParams(w, h).apply { setMargins(m, m, m, m) }
