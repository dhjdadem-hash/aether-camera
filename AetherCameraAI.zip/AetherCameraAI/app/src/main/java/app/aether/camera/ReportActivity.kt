package app.aether.camera

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.hardware.camera2.CameraCharacteristics
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class ReportActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = CameraProbe.report(this)
        val cams = CameraProbe.scan(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
        }
        col.addView(TextView(this).apply { text = "تقرير قدرات الكاميرا"; textSize = 20f; setTextColor(Color.WHITE) })
        col.addView(glassButton("نسخ التقرير") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("report", report))
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
        }, lp(m = dp(4)))
        cams.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }.forEach { c ->
            col.addView(glassButton("اختبر الكاميرا ID ${c.id} (${f1(c.mp)}MP) في المعاينة") {
                getSharedPreferences("aether", MODE_PRIVATE).edit().putString("force", c.id).apply()
                finish()
            }, lp(m = dp(4)))
        }
        col.addView(TextView(this).apply {
            text = report
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.LTGRAY)
            setTextIsSelectable(true)
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(Color.BLACK); addView(col) })
    }
}
