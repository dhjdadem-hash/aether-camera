package app.aether.camera

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraMetadata
import android.hardware.camera2.CaptureRequest
import android.hardware.camera2.CaptureResult
import android.hardware.camera2.TotalCaptureResult
import android.media.MediaMetadataRetriever
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.MediaStore
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.OrientationEventListener
import android.view.ScaleGestureDetector
import android.view.Surface
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.core.UseCase
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.sqrt

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : ComponentActivity() {
    private data class Stop(val label: String, val id: String?, val zoom: Float)

    private lateinit var preview: PreviewView
    private lateinit var zoomLabel: TextView
    private lateinit var statusLabel: TextView
    private lateinit var aiBadge: TextView
    private lateinit var flashBtn: TextView
    private lateinit var stabBtn: TextView
    private lateinit var qualBtn: TextView
    private lateinit var modePhoto: TextView
    private lateinit var modeVideo: TextView
    private lateinit var shutter: View
    private lateinit var chipRow: LinearLayout
    private lateinit var orient: OrientationEventListener

    private val exec = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null

    private lateinit var cams: List<Cam>
    private var main: Cam? = null
    private var wide: Wide = Wide.None("")
    private var stops = listOf<Stop>()
    private var currentId: String? = null
    private var front = false
    private var videoMode = false
    private var aiOn = true
    private var stab = 0
    private var flash = ImageCapture.FLASH_MODE_OFF
    private var quality: Quality = Quality.HIGHEST
    @Volatile private var appliedStab = -1
    @Volatile private var appliedOis = -1

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasPerm(Manifest.permission.CAMERA)) startCamera() else toast("إذن الكاميرا مطلوب", true)
    }

    private fun hasPerm(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String, long: Boolean = false) =
        Toast.makeText(this, s, if (long) Toast.LENGTH_LONG else Toast.LENGTH_SHORT).show()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cams = CameraProbe.scan(this)
        main = CameraProbe.main(cams)
        wide = CameraProbe.findWide(cams)
        currentId = main?.id
        buildUi()
        buildStops()
        orient = object : OrientationEventListener(this) {
            override fun onOrientationChanged(o: Int) {
                if (o == ORIENTATION_UNKNOWN) return
                val r = when (o) {
                    in 45..134 -> Surface.ROTATION_270
                    in 135..224 -> Surface.ROTATION_180
                    in 225..314 -> Surface.ROTATION_90
                    else -> Surface.ROTATION_0
                }
                imageCapture?.targetRotation = r
                videoCapture?.targetRotation = r
            }
        }
        permLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
    }

    override fun onStart() { super.onStart(); orient.enable() }
    override fun onStop() { super.onStop(); orient.disable(); recording?.stop() }

    override fun onResume() {
        super.onResume()
        val p = getSharedPreferences("aether", MODE_PRIVATE)
        val id = p.getString("force", null)
        if (id != null) {
            p.edit().remove("force").apply()
            front = false; currentId = id
            bind(id, 1f, true)
        }
    }

    // ---------------- UI ----------------
    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        preview = PreviewView(this).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
        root.addView(preview, FrameLayout.LayoutParams(MATCH, MATCH))

        val scale = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val cur = camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: return false
                setZoom(cur * d.scaleFactor)
                return true
            }
        })
        val tap = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean { focusAt(e.x, e.y); return true }
        })
        preview.setOnTouchListener { _, ev ->
            scale.onTouchEvent(ev)
            if (!scale.isInProgress) tap.onTouchEvent(ev)
            true
        }

        flashBtn = glassButton("⚡ إيقاف") { cycleFlash() }
        aiBadge = glassButton("AI ✓") { aiOn = !aiOn; aiBadge.text = if (aiOn) "AI ✓" else "AI ✕" }
        stabBtn = glassButton("تثبيت: إيقاف") { cycleStab() }
        qualBtn = glassButton(qName(quality)) { cycleQuality() }
        val rep = glassButton("📊") { startActivity(Intent(this, ReportActivity::class.java)) }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        listOf(flashBtn, aiBadge, stabBtn, qualBtn, rep).forEach { top.addView(it, lp(m = dp(3))) }
        stabBtn.visibility = View.GONE
        qualBtn.visibility = View.GONE
        root.addView(top, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP))

        statusLabel = TextView(this).apply { setTextColor(Color.WHITE); textSize = 12f; gravity = Gravity.CENTER }
        zoomLabel = TextView(this).apply { setTextColor(Color.parseColor("#FFC107")); textSize = 14f; gravity = Gravity.CENTER }
        chipRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val chipScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chipRow) }
        modePhoto = glassButton("صورة") { setMode(false) }
        modeVideo = glassButton("فيديو") { setMode(true) }
        val modes = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(modePhoto, lp(m = dp(4)))
            addView(modeVideo, lp(m = dp(4)))
        }
        val gal = glassButton("🖼") { startActivity(Intent(this, GalleryActivity::class.java)) }
        val sw = glassButton("🔄") {
            if (recording != null) toast("أوقف التسجيل أولًا") else {
                front = !front
                currentId = if (front) null else main?.id
                bind(currentId, 1f, false)
            }
        }
        shutter = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.WHITE)
                setStroke(dp(4), 0x99FFFFFF.toInt())
            }
            setOnClickListener { if (videoMode) toggleRecord() else takePhoto() }
        }
        val ctl = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            addView(gal, lp(dp(52), dp(52), dp(24)))
            addView(shutter, lp(dp(72), dp(72), dp(24)))
            addView(sw, lp(dp(52), dp(52), dp(24)))
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(8), dp(8), dp(8), dp(12))
            background = glass(26, 0x55000000, 0x33FFFFFF)
            listOf<View>(statusLabel, zoomLabel, chipScroll, modes, ctl).forEach {
                addView(it, lp(WRAP, WRAP).apply { setMargins(0, dp(3), 0, dp(3)) })
            }
        }
        root.addView(bottom, FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM).apply { setMargins(dp(8), 0, dp(8), dp(8)) })
        setContentView(root)
        styleMode()
    }

    private fun styleMode() {
        val amber = Color.parseColor("#FFC107")
        modePhoto.setTextColor(if (!videoMode) amber else Color.WHITE)
        modeVideo.setTextColor(if (videoMode) amber else Color.WHITE)
    }

    private fun fmt(v: Float) = if (v == v.toInt().toFloat()) "${v.toInt()}" else f1(v)

    private fun buildStops() {
        val m = main
        val s = mutableListOf<Stop>()
        when (val w = wide) {
            is Wide.Logical -> {
                if (w.minZoom < 0.79f) { s += Stop(fmt(w.minZoom), m?.id, w.minZoom) }
                s += Stop("0.8", m?.id, 0.8f)
            }
            is Wide.Separate -> {
                if (w.ratio < 0.78f) {
                    s += Stop(fmt(w.ratio), w.id, 1f)
                    s += Stop("0.8", w.id, 0.8f / w.ratio)
                } else {
                    s += Stop(fmt(w.ratio), w.id, 1f)
                }
            }
            is Wide.None -> { s += Stop("0.8✗", null, 0.8f) }
        }
        s += Stop("1", m?.id, 1f)
        for (z in listOf(2f, 5f, 10f, 20f, 50f, 120f)) {
            if (m == null || z <= m.maxZoom) { s += Stop(fmt(z), m?.id, z) }
        }
        stops = s
        chipRow.removeAllViews()
        s.forEach { st -> chipRow.addView(glassButton(st.label + "x") { applyStop(st) }, lp(m = dp(3))) }
    }

    // ---------------- Camera ----------------
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({ provider = f.get(); bind(currentId, 1f, false) }, ContextCompat.getMainExecutor(this))
    }

    private fun selectorFor(id: String?): CameraSelector {
        if (front) return CameraSelector.DEFAULT_FRONT_CAMERA
        if (id == null) return CameraSelector.DEFAULT_BACK_CAMERA
        return CameraSelector.Builder()
            .addCameraFilter { infos -> infos.filter { Camera2CameraInfo.from(it).cameraId == id } }
            .build()
    }

    private fun <T> stabOpts(e: Camera2Interop.Extender<T>, mode: Int, ois: Int) {
        e.setCaptureRequestOption(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, mode)
        e.setCaptureRequestOption(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, ois)
    }

    private fun supportsStab(mode: Int) = cams.find { it.id == currentId }?.stab?.contains(mode) == true

    private fun bind(id: String?, zoom: Float, verify: Boolean) {
        val p = provider ?: return
        if (recording != null) { toast("أوقف التسجيل أولًا"); return }
        p.unbindAll()
        val pb = Preview.Builder()
        var ic: ImageCapture? = null
        var vc: VideoCapture<Recorder>? = null
        if (videoMode) {
            val rec = Recorder.Builder()
                .setQualitySelector(QualitySelector.from(quality, FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)))
                .build()
            val vb = VideoCapture.Builder(rec)
            val c = cams.find { it.id == id }
            val mode = when {
                stab == 0 -> CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
                stab == 2 && c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION) == true ->
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION
                c?.stab?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true ->
                    CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON
                else -> CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_OFF
            }
            val ois = if (stab > 0 && c?.ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true)
                CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON else CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_OFF
            stabOpts(Camera2Interop.Extender(pb), mode, ois)
            stabOpts(Camera2Interop.Extender(vb), mode, ois)
            Camera2Interop.Extender(pb).setSessionCaptureCallback(object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
                    appliedStab = res.get(CaptureResult.CONTROL_VIDEO_STABILIZATION_MODE) ?: -1
                    appliedOis = res.get(CaptureResult.LENS_OPTICAL_STABILIZATION_MODE) ?: -1
                }
            })
            vc = vb.build()
        } else {
            ic = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setFlashMode(flash)
                .build()
        }
        val pv = pb.build().also { it.setSurfaceProvider(preview.surfaceProvider) }
        try {
            camera = p.bindToLifecycle(this, selectorFor(id), *listOfNotNull<UseCase>(pv, ic, vc).toTypedArray())
        } catch (e: Exception) {
            toast("تعذر فتح الكاميرا ${id ?: "الأمامية"}: ${e.message}", true)
            if (!front && id != main?.id) { currentId = main?.id; bind(currentId, 1f, false) }
            return
        }
        imageCapture = ic
        videoCapture = vc
        if (camera?.cameraInfo?.hasFlashUnit() == true) {
            camera?.cameraControl?.enableTorch(videoMode && flash == ImageCapture.FLASH_MODE_ON)
        }
        setZoom(zoom)
        updateStatus()
        if (verify || zoom < 1f) preview.postDelayed({ verifyPreview() }, 1500)
    }

    private fun verifyPreview() {
        val streaming = preview.previewStreamState.value == PreviewView.StreamState.STREAMING
        val bmp = preview.bitmap
        var bad = !streaming
        if (bmp != null) {
            val s = Bitmap.createScaledBitmap(bmp, 32, 32, true)
            var sum = 0.0; var sq = 0.0
            for (y in 0 until 32) for (x in 0 until 32) {
                val p = s.getPixel(x, y)
                val l = Color.red(p) * 0.299 + Color.green(p) * 0.587 + Color.blue(p) * 0.114
                sum += l; sq += l * l
            }
            val mean = sum / 1024.0
            val sd = sqrt((sq / 1024.0 - mean * mean).coerceAtLeast(0.0))
            if (mean < 6 || sd < 2.5) bad = true
        }
        if (bad && !front && currentId != main?.id) {
            toast("معاينة هذه الكاميرا سوداء/فارغة أو لا تبث؛ عدت إلى الكاميرا الرئيسية.", true)
            currentId = main?.id
            bind(currentId, 1f, false)
        } else if (bad) {
            toast("المعاينة تبدو فارغة (سوداء/رمادية). قد تكون الكاميرا مغطاة أو لا تعمل.", true)
        }
    }

    private fun setZoom(z: Float) {
        val cam = camera ?: return
        val st = cam.cameraInfo.zoomState.value
        val zz = if (st != null) z.coerceIn(st.minZoomRatio, st.maxZoomRatio) else z
        cam.cameraControl.setZoomRatio(zz)
        showZoom(zz)
        if (z > zz + 0.05f) toast("أقصى تكبير يدعمه هذا الجهاز ${f1(zz)}x")
    }

    private fun showZoom(z: Float) {
        val m = main
        val t = cams.filter { it.facing == CameraCharacteristics.LENS_FACING_BACK }.maxOfOrNull { it.f35 } ?: 0f
        val tele = if (m != null && m.f35 > 0f && t > 0f) t / m.f35 else 1f
        val kind = when {
            z < 0.99f -> "مجال واسع"
            z <= 1.01f -> ""
            tele >= 1.5f && z <= tele -> "بصري/هجين"
            z > 10f -> "رقمي — جودة منخفضة جدًا (تفاصيل تقديرية)"
            z > 4f -> "رقمي — الجودة تنخفض"
            else -> "رقمي (قص برمجي)"
        }
        zoomLabel.text = f1(z) + "x" + if (kind.isNotEmpty()) " · $kind" else ""
    }

    private fun applyStop(st: Stop) {
        if (front) { toast("الزوم و0.8x للكاميرا الخلفية فقط"); return }
        val w = wide
        if (st.id == null && w is Wide.None) { toast(w.why, true); return }
        val id = st.id ?: currentId
        if (id != currentId) {
            currentId = id
            bind(id, st.zoom, true)
        } else {
            setZoom(st.zoom)
            if (st.zoom < 1f) preview.postDelayed({ verifyPreview() }, 1500)
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val pt = preview.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
    }

    private fun setMode(video: Boolean) {
        if (recording != null || video == videoMode) return
        videoMode = video
        styleMode()
        stabBtn.visibility = if (video) View.VISIBLE else View.GONE
        qualBtn.visibility = if (video) View.VISIBLE else View.GONE
        (shutter.background as GradientDrawable).setColor(if (video) Color.RED else Color.WHITE)
        bind(currentId, camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f, false)
    }

    private fun cycleFlash() {
        if (camera?.cameraInfo?.hasFlashUnit() != true) { toast("لا يوجد فلاش LED لهذه الكاميرا"); return }
        flash = when (flash) {
            ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
            ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
            else -> ImageCapture.FLASH_MODE_OFF
        }
        imageCapture?.flashMode = flash
        camera?.cameraControl?.enableTorch(videoMode && flash == ImageCapture.FLASH_MODE_ON)
        flashBtn.text = when (flash) {
            ImageCapture.FLASH_MODE_AUTO -> "⚡ تلقائي"
            ImageCapture.FLASH_MODE_ON -> if (videoMode) "⚡ مصباح" else "⚡ تشغيل"
            else -> "⚡ إيقاف"
        }
    }

    private fun cycleStab() {
        if (recording != null) { toast("لا يمكن تغيير التثبيت أثناء التسجيل"); return }
        val c = cams.find { it.id == currentId }
        var n = (stab + 1) % 3
        if (n == 2 && !supportsStab(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_PREVIEW_STABILIZATION)) {
            toast("التثبيت النشط (Preview Stabilization) غير مدعوم في هذه الكاميرا")
            n = 0
        }
        if (n == 1 && !supportsStab(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) &&
            c?.ois?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) != true
        ) {
            toast("هذه الكاميرا لا تدعم أي نوع تثبيت")
            n = 0
        }
        stab = n
        stabBtn.text = "تثبيت: " + arrayOf("إيقاف", "عادي", "نشط")[n]
        bind(currentId, camera?.cameraInfo?.zoomState?.value?.zoomRatio ?: 1f, false)
    }

    private fun qName(q: Quality) = when (q) {
        Quality.UHD -> "4K"
        Quality.FHD -> "1080p"
        Quality.HD -> "720p"
        Quality.SD -> "480p"
        else -> "أعلى جودة"
    }

    private fun cycleQuality() {
        if (recording != null) { toast("لا يمكن تغيير الجودة أثناء التسجيل"); return }
        val cam = camera ?: return
        val sup = QualitySelector.getSupportedQualities(cam.cameraInfo)
        if (sup.isEmpty()) { toast("لا توجد جودات فيديو مدعومة"); return }
        val i = sup.indexOf(quality)
        quality = sup[(i + 1) % sup.size]
        qualBtn.text = qName(quality)
        bind(currentId, cam.cameraInfo.zoomState.value?.zoomRatio ?: 1f, false)
    }

    private fun updateStatus() {
        val free = StatFs(Environment.getDataDirectory().path).availableBytes shr 20
        val base = "ID ${if (front) "أمامية" else currentId} · ${free}MB متاح"
        statusLabel.text = base
        if (videoMode) statusLabel.postDelayed({
            if (recording == null) statusLabel.text = "$base · ${qName(quality)} · تثبيت فعلي: صورة=$appliedStab بصري=$appliedOis"
        }, 1500)
    }

    // ---------------- Photo ----------------
    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun takePhoto() {
        val ic = imageCapture ?: return
        val name = "AETHER_" + stamp()
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/AetherCamera")
        }
        val opts = ImageCapture.OutputFileOptions.Builder(contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv).build()
        ic.takePicture(opts, ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) {
                val uri = r.savedUri ?: return
                toast("تم حفظ الأصل")
                if (aiOn) {
                    aiBadge.text = "AI …"
                    exec.execute {
                        val out = try { AiColor.processFile(contentResolver, uri, name) } catch (e: Throwable) { null }
                        runOnUiThread {
                            aiBadge.text = if (aiOn) "AI ✓" else "AI ✕"
                            toast(if (out != null) "تم حفظ النسخة المحسّنة (_AI)" else "فشلت المعالجة؛ الأصل محفوظ", out == null)
                        }
                    }
                }
            }
            override fun onError(e: ImageCaptureException) { toast("فشل الالتقاط: ${e.message}", true) }
        })
    }

    // ---------------- Video ----------------
    private fun mmss(nanos: Long): String {
        val s = nanos / 1_000_000_000L
        return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
    }

    private fun toggleRecord() {
        val r = recording
        if (r != null) { r.stop(); return }
        val vc = videoCapture ?: return
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "AETHER_${stamp()}.mp4")
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/AetherCamera")
        }
        val out = MediaStoreOutputOptions.Builder(contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(cv).build()
        var pending = vc.output.prepareRecording(this, out)
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled()
        try {
            recording = pending.start(ContextCompat.getMainExecutor(this)) { ev ->
                when (ev) {
                    is VideoRecordEvent.Start -> { shutter.alpha = 0.55f }
                    is VideoRecordEvent.Status -> { statusLabel.text = "● ${mmss(ev.recordingStats.recordedDurationNanos)}" }
                    is VideoRecordEvent.Finalize -> {
                        shutter.alpha = 1f
                        recording = null
                        onFinalize(ev)
                        updateStatus()
                    }
                    else -> {}
                }
            }
        } catch (e: Exception) {
            recording = null
            toast("تعذر بدء التسجيل: ${e.message}", true)
        }
    }

    private fun onFinalize(ev: VideoRecordEvent.Finalize) {
        if (ev.hasError()) {
            when (ev.error) {
                VideoRecordEvent.Finalize.ERROR_NO_VALID_DATA -> toast("التسجيل قصير جدًا؛ لم يُحفظ", true)
                VideoRecordEvent.Finalize.ERROR_INSUFFICIENT_STORAGE -> toast("مساحة التخزين ممتلئة؛ قد يكون الفيديو ناقصًا", true)
                else -> toast("حدث خطأ (${ev.error}) وقد لا يكون جزء من الفيديو محفوظًا", true)
            }
            return
        }
        val uri = ev.outputResults.outputUri
        var dur = 0L
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } catch (e: Exception) {
            dur = 0L
        } finally {
            r.release()
        }
        toast(if (dur > 0) "تم حفظ الفيديو (${dur / 1000}s) وتم التحقق من إمكان قراءته" else "حُفظ الملف لكن تعذر التحقق من تشغيله", dur <= 0)
    }
}
