package com.aether.camera

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.camera2.params.OutputConfiguration
import android.hardware.camera2.params.SessionConfiguration
import android.media.ExifInterface
import android.media.ImageReader
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Range
import android.util.Size
import android.view.*
import android.view.animation.OvershootInterpolator
import android.widget.*
import java.io.ByteArrayInputStream
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import kotlin.math.*

class MainActivity : Activity() {
    class Cam(val id: String, val phys: String?, val mp: Double, val back: Boolean, val mono: Boolean) { val key get() = phys ?: id }
    private class Item(val uri: Uri, val name: String, val video: Boolean)

    private lateinit var cm: CameraManager
    private val cams = ArrayList<Cam>(); private val parent = HashMap<String, String>()
    private var main: Cam? = null; private var wide: Cam? = null; private var front: Cam? = null; private var cur: Cam? = null
    private var dev: CameraDevice? = null; private var sess: CameraCaptureSession? = null; private var req: CaptureRequest.Builder? = null
    private var reader: ImageReader? = null; private var rec: MediaRecorder? = null; private var recFile: File? = null
    private var recStart = 0L; private var recording = false
    private val bgT = HandlerThread("cam").apply { start() }; private val bg = Handler(bgT.looper); private val ui = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout; private lateinit var tv: TextureView; private lateinit var shutter: Shutter
    private lateinit var flashB: TextView; private lateinit var aiB: TextView; private lateinit var stabB: TextView
    private lateinit var resB: TextView; private lateinit var fpsB: TextView; private lateinit var photoB: TextView; private lateinit var videoB: TextView
    private lateinit var infoT: TextView; private lateinit var row2: LinearLayout; private lateinit var thumb: ImageView
    private val zChips = ArrayList<TextView>(); private val lv = floatArrayOf(.8f, 1f, 2f, 5f, 10f, 20f, 50f, 120f)
    private var flash = false; private var ai = true; private var video = false; private var stab = 1; private var fpsIdx = 1; private var resW = 3840
    private var zoom = 1f; private var soft = 1f; private var hwMax = 1f; private var hz = 1f; private var crop: Rect? = null
    private var pv = Size(1440, 1080); private var vidSizes: List<Size> = emptyList(); private val fpsOpts = intArrayOf(24, 30, 60)
    private var overlay: View? = null; private var inViewer = false
    private var colorMode = 0; private val colorNames = arrayOf("NATURAL", "VIVID", "WARM", "COOL")
    private lateinit var colorB: TextView; private lateinit var proB: TextView; private lateinit var proPanel: LinearLayout
    private var pro = false; private var iso = 400; private var expNs = 16_666_667L; private var ev = 0; private var focusD = -1f; private var minFocus = 0f
    private var mode = "PHOTO"; private val modeChips = HashMap<String, TextView>()
    private var burstN = 0; private val burstJpegs = ArrayList<ByteArray>(); private var burstKind = ""; private var busy = false
    private var eBase: Bitmap? = null; private var eMask: BooleanArray? = null

    // ---------- lifecycle ----------
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.attributes = window.attributes.apply { layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        buildUi(); setMode("PHOTO"); mark(aiB, true); mark(stabB, true); hilite(); refreshThumb()
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }
    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) { go() }
    override fun onResume() { super.onResume(); go() }
    override fun onPause() { if (recording) finishRec(false); closeCam(); super.onPause() }
    override fun onConfigurationChanged(c: Configuration) { super.onConfigurationChanged(c); fit(); transform() }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (overlay == null) super.onBackPressed() else if (inViewer) openStudio() else hideOverlay() }

    // ---------- UI ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(m: String) { ui.post { Toast.makeText(this, m, Toast.LENGTH_SHORT).show() } }
    private fun glass(r: Float) = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.argb(95, 255, 255, 255), Color.argb(22, 255, 255, 255), Color.argb(55, 190, 215, 255)))
        .apply { cornerRadius = r; setStroke(dp(1), Color.argb(150, 255, 255, 255)) }
    private fun mark(v: TextView, on: Boolean, r: Int = 22) {
        v.background = if (on) GradientDrawable().apply { cornerRadius = dp(r).toFloat(); setColor(Color.argb(235, 255, 255, 255)) } else glass(dp(r).toFloat())
        v.setTextColor(if (on) Color.BLACK else Color.WHITE)
    }
    private fun chip(t: String, pad: Int = 14, on: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12.5f; typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER; setPadding(dp(pad), dp(9), dp(pad), dp(9)); background = glass(dp(22).toFloat())
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(.9f).scaleY(.9f).setDuration(90).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3f)).setDuration(280).start()
            }
            false
        }
        setOnClickListener { it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); on() }
    }
    private fun lp(m: Int = 4) = LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(m), 0, dp(m), 0) }

    inner class Shutter(c: android.content.Context) : View(c) {
        private val p = Paint(Paint.ANTI_ALIAS_FLAG)
        fun pulse() { animate().scaleX(.88f).scaleY(.88f).setDuration(80).withEndAction { animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator(3f)).setDuration(300).start() }.start(); performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }
        override fun onDraw(c: Canvas) {
            val cx = width / 2f; val cy = height / 2f; val r = min(cx, cy)
            p.style = Paint.Style.STROKE; p.strokeWidth = dp(4).toFloat(); p.color = Color.WHITE; c.drawCircle(cx, cy, r - dp(3), p)
            p.style = Paint.Style.FILL
            if (recording) { p.color = Color.rgb(255, 59, 48); val s = r * .42f; c.drawRoundRect(cx - s, cy - s, cx + s, cy + s, dp(8).toFloat(), dp(8).toFloat(), p) }
            else { p.color = if (video) Color.rgb(255, 59, 48) else Color.WHITE; c.drawCircle(cx, cy, r - dp(12), p) }
        }
    }

    private fun buildUi() {
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        tv = TextureView(this)
        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { go() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) { transform() }
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
        root.addView(tv); fit()
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean { setZoom((zoom * d.scaleFactor).coerceIn(.8f, 120f)); return true }
        })
        root.setOnTouchListener { _, e -> sd.onTouchEvent(e); true }

        flashB = chip("FLASH OFF") { flash = !flash; flashB.text = if (flash) "FLASH ON" else "FLASH OFF"; mark(flashB, flash); push() }
        aiB = chip("AI ON") { ai = !ai; aiB.text = if (ai) "AI ON" else "AI OFF"; mark(aiB, ai) }
        stabB = chip("STAB STD") { stab = (stab + 1) % 4; stabB.text = arrayOf("STAB OFF", "STAB STD", "STAB ACTIVE", "STAB LOCKED")[stab]; mark(stabB, stab > 0); push() }
        resB = chip("4K") {
            if (vidSizes.isNotEmpty()) { val i = vidSizes.indexOfFirst { it.width == resW }; resW = vidSizes[(i + 1) % vidSizes.size].width; resB.text = resName(resW) }
        }
        fpsB = chip("30 FPS") { fpsIdx = (fpsIdx + 1) % 3; fpsB.text = "${fpsOpts[fpsIdx]} FPS" }
        infoT = chip("1×") {}; infoT.textSize = 12f
        colorB = chip("COLOR: NATURAL") { colorMode = (colorMode + 1) % 4; colorB.text = "COLOR: " + colorNames[colorMode]; applyColor() }
        proB = chip("PRO OFF") { pro = !pro; proB.text = if (pro) "PRO ON" else "PRO OFF"; mark(proB, pro); proPanel.visibility = if (pro) View.VISIBLE else View.GONE; push() }
        proPanel = buildPro(); root.addView(proPanel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(236)) })
        val row3 = LinearLayout(this).apply { gravity = Gravity.CENTER; addView(colorB, lp()); addView(proB, lp()) }
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER; listOf(flashB, aiB, stabB).forEach { addView(it, lp()) } }
        row2 = LinearLayout(this).apply { gravity = Gravity.CENTER; listOf(resB, fpsB).forEach { addView(it, lp()) } }
        val topBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(top); addView(row2, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            addView(infoT, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
            addView(row3, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(8) })
        }
        root.addView(topBox, FrameLayout.LayoutParams(-1, -2, Gravity.TOP).apply { topMargin = dp(38) })

        val zp = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(dp(4), dp(4), dp(4), dp(4)); background = glass(dp(26).toFloat()) }
        lv.forEach { z ->
            val c = chip((if (z < 1f) "0.8" else z.toInt().toString()) + "×", 8) { setZoom(z) }; c.textSize = 12f; zChips.add(c)
            zp.addView(c, lp(1))
        }
        photoB = chip("PHOTO", 14) { setMode("PHOTO") }; videoB = chip("VIDEO", 14) { setMode("VIDEO") }
        val modeRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER; addView(photoB, lp(4)); addView(videoB, lp(4))
            listOf("PORTRAIT", "NIGHT", "ASTRO", "LONG EXP", "MACRO", "DOC").forEach { n -> val c = chip(n, 14) { setMode(n) }; modeChips[n] = c; addView(c, lp(4)) }
        }
        val modes = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(modeRow) }
        shutter = Shutter(this); shutter.setOnClickListener { onShutter() }
        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; background = glass(dp(30).toFloat())
            outlineProvider = object : ViewOutlineProvider() { override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) } }
            clipToOutline = true; setOnClickListener { openStudio() }
        }
        val flip = chip("FLIP", 18) {
            val t = if (cur?.back == false) main else front
            if (t == null) toast("No other camera found") else { zoom = 1f; hilite(); openCam(t) }
        }
        val ctl = FrameLayout(this).apply {
            addView(thumb, FrameLayout.LayoutParams(dp(58), dp(58), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(34) })
            addView(shutter, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
            addView(flip, FrameLayout.LayoutParams(-2, -2, Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(28) })
        }
        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(zp); addView(modes, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(10) })
            addView(ctl, LinearLayout.LayoutParams(-1, dp(96)).apply { topMargin = dp(6) })
        }
        root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(18) })
        setContentView(root)
    }
    private fun resName(w: Int) = when (w) { 1920 -> "FHD"; 3840 -> "4K"; 7680 -> "8K"; else -> "${w}p" }
    private fun setMode(n: String) {
        mode = n; video = n == "VIDEO"; mark(photoB, n == "PHOTO", 22); mark(videoB, video, 22); modeChips.forEach { (k, c) -> mark(c, k == n, 22) }
        row2.visibility = if (video) View.VISIBLE else View.GONE; shutter.invalidate()
        if (n == "MACRO") setZoom(0.8f)
        val hint = when (n) { "NIGHT" -> "Night: hold very still ~3 s"; "ASTRO" -> "Astro: use a tripod (~35 s)"; "LONG EXP" -> "Long exposure: use a tripod (~6 s)"; "DOC" -> "Document: fill the frame — saved as PDF"; "PORTRAIT" -> "Portrait: needs a person in frame"; else -> "" }
        if (hint.isNotEmpty()) toast(hint)
    }
    private fun hilite() {
        val near = lv.minByOrNull { abs(it - zoom) }
        zChips.forEachIndexed { i, c ->
            val on = lv[i] == near
            c.background = if (on) GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.argb(235, 255, 255, 255)) } else null
            c.setTextColor(if (on) Color.BLACK else Color.WHITE)
        }
    }
    private fun info() = ui.post {
        val c = cur
        infoT.text = if (recording) "● REC  " + (SystemClock.elapsedRealtime() - recStart).let { "%02d:%02d".format(it / 60000, it / 1000 % 60) }
        else if (zoom < 1f && c != null) "0.8× · ${"%.1f".format(c.mp)}MP camera" + (if (c.mono) " · MONO sensor" else "")
        else "%.1f×".format(zoom) + (if (zoom > 10f) " · digital — quality drops" else if (soft > 1f) " · digital" else "")
    }
    private fun fit() {
        val sw = resources.displayMetrics.widthPixels; val sh = resources.displayMetrics.heightPixels; val ar = pv.width.toFloat() / pv.height
        tv.layoutParams = if (sw <= sh) FrameLayout.LayoutParams(sw, (sw * ar).toInt(), Gravity.CENTER) else FrameLayout.LayoutParams((sh * ar).toInt(), sh, Gravity.CENTER)
    }
    @Suppress("DEPRECATION")
    private fun transform() = tv.post {
        val rot = windowManager.defaultDisplay.rotation
        val vw = tv.width.toFloat(); val vh = tv.height.toFloat(); if (vw == 0f) return@post
        val m = Matrix(); val vr = RectF(0f, 0f, vw, vh); val br = RectF(0f, 0f, pv.height.toFloat(), pv.width.toFloat())
        val cx = vr.centerX(); val cy = vr.centerY()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            br.offset(cx - br.centerX(), cy - br.centerY()); m.setRectToRect(vr, br, Matrix.ScaleToFit.FILL)
            val sc = max(vh / pv.height, vw / pv.width); m.postScale(sc, sc, cx, cy); m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) m.postRotate(180f, cx, cy)
        tv.setTransform(m)
    }

    // ---------- camera discovery (tries listed, physical AND hidden ids) ----------
    private fun discover() {
        cams.clear(); parent.clear(); val seen = HashSet<String>()
        fun add(id: String, phys: String?) {
            val k = phys ?: id; if (!seen.add(k)) return
            try {
                val ch = cm.getCameraCharacteristics(k)
                val ps = ch.get(CameraCharacteristics.SENSOR_INFO_PIXEL_ARRAY_SIZE) ?: return
                val cfa = ch.get(CameraCharacteristics.SENSOR_INFO_COLOR_FILTER_ARRANGEMENT) ?: 0
                if (phys != null) parent[phys] = id
                cams.add(Cam(id, phys, ps.width * ps.height / 1e6, ch.get(CameraCharacteristics.LENS_FACING) != CameraCharacteristics.LENS_FACING_FRONT, cfa == 5 || cfa == 6))
            } catch (e: Exception) {}
        }
        val listed = cm.cameraIdList.toList()
        listed.forEach { add(it, null) }
        listed.forEach { id -> try { cm.getCameraCharacteristics(id).physicalCameraIds.forEach { add(id, it) } } catch (e: Exception) {} }
        for (i in 0..15) { val s = i.toString(); if (s !in listed) add(s, null) }
        val backs = cams.filter { it.back }
        main = backs.filter { it.phys == null && it.id in listed }.maxByOrNull { it.mp } ?: backs.maxByOrNull { it.mp }
        val others = backs.filter { it != main }
        wide = others.filter { it.mp <= 3.5 && it.mp >= 1.0 }.minByOrNull { abs(it.mp - 2.0) } ?: others.minByOrNull { it.mp }
        front = cams.firstOrNull { !it.back }
        if (wide == null) toast("Android exposes no second back camera to apps on this phone")
    }
    private fun chars(c: Cam) = try { cm.getCameraCharacteristics(c.key) } catch (e: Exception) { cm.getCameraCharacteristics(c.id) }
    private fun go() {
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED || !tv.isAvailable) return
        if (cams.isEmpty()) discover()
        val c = cur ?: main ?: cams.firstOrNull() ?: run { toast("No camera found"); return }
        openCam(c)
    }
    private fun openCam(c: Cam) {
        closeCam(); cur = c
        val id = if (c.phys != null) parent[c.phys] ?: c.phys else c.id
        try {
            cm.openCamera(id, object : CameraDevice.StateCallback() {
                override fun onOpened(d: CameraDevice) { dev = d; startSession() }
                override fun onDisconnected(d: CameraDevice) { d.close() }
                override fun onError(d: CameraDevice, e: Int) {
                    d.close(); dev = null; toast("Camera ${c.key} refused to open (error $e)")
                    val m = main; if (c != m && m != null) { zoom = 1f; ui.post { hilite(); openCam(m) } }
                }
            }, ui)
        } catch (e: Exception) {
            toast("Cannot open camera ${c.key}: ${e.message}")
            val m = main; if (c != m && m != null) { zoom = 1f; hilite(); openCam(m) }
        }
    }
    private fun closeCam() {
        try { sess?.close() } catch (e: Exception) {}; sess = null
        try { dev?.close() } catch (e: Exception) {}; dev = null
        try { reader?.close() } catch (e: Exception) {}; reader = null; req = null
    }
    private fun setZoom(z: Float) {
        zoom = z; val t = if (z < 1f) wide ?: main else main
        if (t != null && t != cur && !recording) openCam(t) else push()
        hilite(); info()
    }

    // ---------- session / preview ----------
    private fun startSession() {
        val d = dev ?: return; val c = cur ?: return
        try {
            val ch = chars(c); val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
            val ps = map.getOutputSizes(SurfaceTexture::class.java)
            pv = ps.filter { it.width * 3 == it.height * 4 && it.width <= 1600 }.maxByOrNull { it.width } ?: ps.first()
            val js = map.getOutputSizes(ImageFormat.JPEG).let { a -> a.filter { it.width * 3 == it.height * 4 }.maxByOrNull { it.width * it.height } ?: a.first() }
            vidSizes = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()).filter { it.width * 9 == it.height * 16 && it.width in listOf(1920, 3840, 7680) }.sortedBy { it.width }
            if (vidSizes.isNotEmpty() && vidSizes.none { it.width == resW }) resW = vidSizes.last().width
            ui.post { resB.text = resName(resW); fit(); transform(); applyColor() }
            val st = tv.surfaceTexture ?: return; st.setDefaultBufferSize(pv.width, pv.height)
            val sv = Surface(st); val outs = arrayListOf(sv)
            if (recording) { prepRec(vidSizes.firstOrNull { it.width == resW } ?: vidSizes.lastOrNull() ?: Size(1920, 1080), ch); outs.add(rec!!.surface) }
            else { reader = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 10).also { it.setOnImageAvailableListener({ r -> onJpeg(r) }, bg) }; outs.add(reader!!.surface) }
            val cfgs = outs.map { s -> OutputConfiguration(s).also { if (c.phys != null && parent.containsKey(c.phys)) it.setPhysicalCameraId(c.phys) } }
            d.createCaptureSession(SessionConfiguration(SessionConfiguration.SESSION_REGULAR, cfgs, mainExecutor, object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    sess = s
                    req = d.createCaptureRequest(if (recording) CameraDevice.TEMPLATE_RECORD else CameraDevice.TEMPLATE_PREVIEW).apply { addTarget(sv); if (recording) addTarget(outs[1]) }
                    push()
                    if (recording) try { rec?.start(); recStart = SystemClock.elapsedRealtime(); tick() } catch (e: Exception) { recording = false; toast("Recorder failed: ${e.message}"); shutter.invalidate() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("This camera/size cannot stream — try another zoom level") }
            }))
        } catch (e: Exception) { toast("Camera error: ${e.message}") }
    }
    private fun push() {
        val r = req ?: return; val s = sess ?: return; val c = cur ?: return
        try {
            val ch = chars(c)
            r.set(CaptureRequest.CONTROL_AF_MODE, if (recording) CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            r.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
            r.set(CaptureRequest.FLASH_MODE, if (flash && recording) CaptureRequest.FLASH_MODE_TORCH else CaptureRequest.FLASH_MODE_OFF)
            applyManual(r, ch)
            val zr = ch.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            hwMax = zr?.upper ?: ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f
            hz = zoom.coerceIn(1f, max(hwMax, 1f)); if (stab == 3 && recording) hz = max(hz, min(2f, max(hwMax, 1f))); soft = if (zoom > hwMax) zoom / hwMax else 1f
            if (zr != null) r.set(CaptureRequest.CONTROL_ZOOM_RATIO, hz.coerceAtLeast(zr.lower)); crop = null
            if (zr == null) { val a = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!; val w = (a.width() / hz).toInt(); val h = (a.height() / hz).toInt()
                crop = Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2); r.set(CaptureRequest.SCALER_CROP_REGION, crop) }
            ui.post { tv.scaleX = soft; tv.scaleY = soft }
            val vs = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES) ?: intArrayOf()
            val want = when (stab) { 1, 3 -> 1; 2 -> if (vs.contains(2)) 2 else 1; else -> 0 }
            r.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, if (want == 0 || vs.contains(want)) want else 0)
            val ois = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION) ?: intArrayOf()
            r.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (stab > 0 && ois.contains(1)) 1 else 0)
            if (recording) { val f = fpsOpts[fpsIdx]; ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.filter { it.upper == f }?.maxByOrNull { it.lower }?.let { r.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, it) } }
            s.setRepeatingRequest(r.build(), null, bg); info()
        } catch (e: Exception) {}
    }
    @Suppress("DEPRECATION")
    private fun jpegOri(ch: CameraCharacteristics): Int {
        val so = ch.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val deg = when (windowManager.defaultDisplay.rotation) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        return if (ch.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT) (so + deg) % 360 else (so - deg + 360) % 360
    }

    // ---------- photo ----------
    private fun onShutter() {
        if (!video) { shutter.pulse(); if (mode == "NIGHT" || mode == "ASTRO" || mode == "LONG EXP") burst() else shoot(); return }
        if (!recording) { recording = true; shutter.invalidate(); startSession() } else stopRec()
    }
    private fun shoot() {
        val d = dev ?: return; val s = sess ?: return; val rd = reader ?: return; val c = cur ?: return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE); b.addTarget(rd.surface)
            b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
            b.set(CaptureRequest.CONTROL_AE_MODE, if (flash) CaptureRequest.CONTROL_AE_MODE_ON_ALWAYS_FLASH else CaptureRequest.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.FLASH_MODE, if (flash) CaptureRequest.FLASH_MODE_SINGLE else CaptureRequest.FLASH_MODE_OFF)
            applyManual(b, chars(c))
            if (crop != null) b.set(CaptureRequest.SCALER_CROP_REGION, crop) else if (chars(c).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) != null) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hz)
            b.set(CaptureRequest.JPEG_ORIENTATION, jpegOri(chars(c))); b.set(CaptureRequest.JPEG_QUALITY, 97.toByte())
            s.capture(b.build(), null, bg)
        } catch (e: Exception) { toast("Capture failed: ${e.message}") }
    }
    private fun onJpeg(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        val bytes = img.planes[0].buffer.let { ByteArray(it.remaining()).also { a -> it.get(a) } }; img.close()
        if (burstN > 0) { burstJpegs.add(bytes); if (burstJpegs.size >= burstN) { val l = ArrayList(burstJpegs); burstN = 0; burstJpegs.clear(); stack(l, burstKind) }; return }
        val t = System.currentTimeMillis(); val mono = cur?.mono == true; val s = soft; val doAi = ai
        val isWide = cur == wide && cur != main; val toned = isWide || colorMode != 0; val cmode = colorMode; val pm = mode == "PORTRAIT"; val dc = mode == "DOC"
        insert("IMG_$t.jpg", "image/jpeg", "Pictures/Aether") { it.write(bytes) }   // original is ALWAYS kept
        toast(if (doAi) "Original saved · AI enhancing…" else "Saved"); refreshThumb()
        if (!doAi && s <= 1.01f && !toned && !pm && !dc) return
        try {
            var bm = decode(bytes, 16_000_000L)
            if (s > 1.01f) { val cw = (bm.width / s).toInt(); val chh = (bm.height / s).toInt(); val w0 = bm.width; val h0 = bm.height
                bm = Bitmap.createScaledBitmap(Bitmap.createBitmap(bm, (w0 - cw) / 2, (h0 - chh) / 2, cw, chh), w0, h0, true) }
            if (dc) { savePdf(scanFilter(bm), "SCAN_$t.pdf"); toast("Scan saved as PDF in Documents/Aether"); return }
            val ch0 = chroma(bm)
            if (isWide && ch0 < 6f) toast("2MP camera sends NO color data (grayscale sensor): real color can't be recovered, tone applied")
            if (doAi) bm = enhance(bm, mono || ch0 < 6f, true)
            if (toned) bm = tone(bm, cmode)
            if (pm) { segBlur(bm, 0) { out -> save(out, "IMG_${t}_PORTRAIT.jpg"); toast("Portrait ready ✓"); refreshThumb() }; return }
            val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 95, o)
            insert("IMG_${t}_${if (doAi) "AI" else "Z"}.jpg", "image/jpeg", "Pictures/Aether") { it.write(o.toByteArray()) }
            toast(if (doAi) "AI version ready ✓" else "Zoomed copy saved (digital zoom)"); refreshThumb()
        } catch (e: Throwable) { toast("AI failed (${e.message}) — original is safe") }
    }

    // ---------- video ----------
    @Suppress("DEPRECATION")
    private fun prepRec(vs: Size, ch: CameraCharacteristics) {
        val f = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "VID_${System.currentTimeMillis()}.mp4"); recFile = f
        val fps = fpsOpts[fpsIdx]
        rec = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()).apply {
            setAudioSource(MediaRecorder.AudioSource.CAMCORDER); setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); setOutputFile(f.absolutePath)
            setVideoEncodingBitRate((vs.width.toLong() * vs.height * fps / 6).toInt().coerceIn(8_000_000, 150_000_000))
            setVideoFrameRate(fps); setVideoSize(vs.width, vs.height)
            setVideoEncoder(if (vs.width >= 3840) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC); setAudioEncodingBitRate(192000); setAudioSamplingRate(48000)
            setOrientationHint(jpegOri(ch)); prepare()
        }
    }
    private fun tick() { ui.postDelayed({ if (recording) { info(); tick() } }, 500) }
    private fun stopRec() {   // never stop before 1.3 s: avoids "recording time too short"
        val wait = 1300 - (SystemClock.elapsedRealtime() - recStart)
        if (wait > 0 && recStart > 0) ui.postDelayed({ if (recording) finishRec(true) }, wait) else finishRec(true)
    }
    private fun finishRec(restart: Boolean) {
        recording = false; val f = recFile; val r = rec; rec = null; var ok = r != null
        try { sess?.stopRepeating() } catch (e: Exception) {}
        try { r?.stop() } catch (e: RuntimeException) { ok = false }
        try { r?.release() } catch (e: Exception) {}
        if (ok && f != null && f.length() > 0) bg.post {
            val u = insert(f.name, "video/mp4", "Movies/Aether") { o -> f.inputStream().use { it.copyTo(o) } }
            if (u != null) f.delete()
            toast(if (u != null) "Video saved ✓" else "Save failed — file kept in app storage"); refreshThumb()
        } else { f?.delete(); toast("Recording failed or too short — nothing saved") }
        ui.post { shutter.invalidate(); info() }
        if (restart) startSession()
    }

    // ---------- storage ----------
    private fun insert(name: String, mime: String, rel: String, write: (OutputStream) -> Unit): Uri? {
        val coll = when { mime.startsWith("image") -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI; mime.startsWith("video") -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI; else -> MediaStore.Files.getContentUri("external") }
        val cv = ContentValues().apply { put(MediaStore.MediaColumns.DISPLAY_NAME, name); put(MediaStore.MediaColumns.MIME_TYPE, mime); put(MediaStore.MediaColumns.RELATIVE_PATH, rel); put(MediaStore.MediaColumns.IS_PENDING, 1) }
        val uri = contentResolver.insert(coll, cv) ?: return null
        return try { contentResolver.openOutputStream(uri)?.use(write); cv.clear(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0); contentResolver.update(uri, cv, null, null); uri }
        catch (e: Exception) { contentResolver.delete(uri, null, null); null }
    }
    private fun items(): List<Item> {
        val out = ArrayList<Item>()
        for (v in listOf(false, true)) {
            val coll = if (v) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            contentResolver.query(coll, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME), "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("%Aether%"), null)?.use { c ->
                while (c.moveToNext()) out.add(Item(ContentUris.withAppendedId(coll, c.getLong(0)), c.getString(1), v))
            }
        }
        return out.sortedByDescending { it.name.filter { c -> c.isDigit() }.take(13).toLongOrNull() ?: 0L }
    }
    private fun refreshThumb() { bg.post {
        val m = items().firstOrNull()
        val bm = m?.let { try { contentResolver.loadThumbnail(it.uri, Size(200, 200), null) } catch (e: Exception) { null } }
        ui.post { thumb.setImageBitmap(bm) }
    } }
    private fun bytes(u: Uri) = contentResolver.openInputStream(u)!!.use { it.readBytes() }

    // ---------- Night / Astro / Long exposure: real multi-frame stacking ----------
    private fun zoomInto(b: CaptureRequest.Builder, c: Cam) {
        if (crop != null) b.set(CaptureRequest.SCALER_CROP_REGION, crop) else if (chars(c).get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE) != null) b.set(CaptureRequest.CONTROL_ZOOM_RATIO, hz)
    }
    private fun burst() {
        if (busy) { toast("Still processing the last shot…"); return }
        val d = dev ?: return; val s = sess ?: return; val rd = reader ?: return; val c = cur ?: return
        try {
            val ch = chars(c); val n = if (mode == "NIGHT") 6 else 8
            val er = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 100_000_000L)
            val ir = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 800)
            val cr = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE)
            val reqs = ArrayList<CaptureRequest>()
            repeat(n) {
                val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE); b.addTarget(rd.surface)
                if (mode == "NIGHT") { b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON); if (cr != null) b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, min(cr.upper, 4)) }
                else {
                    b.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
                    b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, (if (mode == "ASTRO") 4_000_000_000L else 600_000_000L).coerceIn(er.lower, er.upper))
                    b.set(CaptureRequest.SENSOR_SENSITIVITY, (if (mode == "ASTRO") 1600 else 100).coerceIn(ir.lower, ir.upper))
                }
                if (mode == "ASTRO") { b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF); b.set(CaptureRequest.LENS_FOCUS_DISTANCE, 0f) }
                else b.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                zoomInto(b, c); b.set(CaptureRequest.JPEG_ORIENTATION, jpegOri(ch)); b.set(CaptureRequest.JPEG_QUALITY, 95.toByte()); reqs.add(b.build())
            }
            burstJpegs.clear(); burstN = n; burstKind = mode; busy = true
            toast("$mode: capturing $n frames — keep the phone still"); s.captureBurst(reqs, null, bg)
            ui.postDelayed({ if (busy && burstN > 0) { busy = false; burstN = 0; toast("Burst timed out — try again") } }, 70_000)
        } catch (e: Exception) { busy = false; burstN = 0; toast("Burst failed: ${e.message}") }
    }
    private fun stack(list: List<ByteArray>, kind: String) {
        try {
            val t = System.currentTimeMillis()
            insert("IMG_$t.jpg", "image/jpeg", "Pictures/Aether") { it.write(list[0]) }   // first frame = original
            val first = decode(list[0], 6_000_000L); val w = first.width; val h = first.height; val n = w * h
            val acc = IntArray(n * 3); var k = 0
            for (b in list) {
                val bm = if (k == 0) first else decode(b, 6_000_000L); val p = IntArray(n); bm.getPixels(p, 0, w, 0, 0, w, h)
                for (i in 0 until n) { val v = p[i]; acc[3 * i] += (v shr 16) and 255; acc[3 * i + 1] += (v shr 8) and 255; acc[3 * i + 2] += v and 255 }
                k++
            }
            val o = IntArray(n) { i -> (255 shl 24) or ((acc[3 * i] / k) shl 16) or ((acc[3 * i + 1] / k) shl 8) or (acc[3 * i + 2] / k) }
            var out = Bitmap.createBitmap(o, w, h, Bitmap.Config.ARGB_8888)
            if (kind != "LONG EXP") out = enhance(out, false, true)
            save(out, "IMG_${t}_${kind.replace(" ", "")}.jpg"); toast("$kind done ✓ — $k frames merged")
        } catch (e: Throwable) { toast("$kind failed: ${e.message}") } finally { busy = false; refreshThumb() }
    }
    private fun save(bm: Bitmap, name: String) { val o = ByteArrayOutputStream(); bm.compress(Bitmap.CompressFormat.JPEG, 95, o); insert(name, "image/jpeg", "Pictures/Aether") { it.write(o.toByteArray()) } }
    private fun savePdf(bm: Bitmap, name: String) {
        val doc = android.graphics.pdf.PdfDocument(); val pg = doc.startPage(android.graphics.pdf.PdfDocument.PageInfo.Builder(bm.width, bm.height, 1).create())
        pg.canvas.drawBitmap(bm, 0f, 0f, null); doc.finishPage(pg)
        val bo = ByteArrayOutputStream(); doc.writeTo(bo); doc.close(); insert(name, "application/pdf", "Documents/Aether") { it.write(bo.toByteArray()) }
    }
    // document scan: divides by the blurred background (removes shadows/uneven light) then boosts contrast
    private fun scanFilter(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val bgb = Bitmap.createScaledBitmap(Bitmap.createScaledBitmap(src, max(w / 30, 1), max(h / 30, 1), true), w, h, true)
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h); val b = IntArray(w * h); bgb.getPixels(b, 0, w, 0, 0, w, h)
        for (i in a.indices) {
            val v = a[i]; val u = b[i]
            val g = .299f * ((v shr 16) and 255) + .587f * ((v shr 8) and 255) + .114f * (v and 255)
            val bv = max(1f, .299f * ((u shr 16) and 255) + .587f * ((u shr 8) and 255) + .114f * (u and 255))
            val o = (((g / bv) * 268f - 40f) * 1.25f).toInt().coerceIn(0, 255)
            a[i] = (255 shl 24) or (o shl 16) or (o shl 8) or o
        }
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }
    // ---------- Portrait / background (ML Kit selfie segmentation, on-device) ----------
    private fun segBlur(src: Bitmap, kind: Int, cb: (Bitmap) -> Unit) {
        val seg = Segmentation.getClient(SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build())
        seg.process(InputImage.fromBitmap(src, 0)).addOnSuccessListener { m -> bg.post {
            try {
                val w = src.width; val h = src.height; val mw = m.width; val mh = m.height; val buf = m.buffer; buf.rewind()
                val conf = FloatArray(mw * mh) { buf.getFloat() }
                if (conf.count { it > .5f } < conf.size / 100) { toast("No person detected in this photo"); return@post }
                val p = IntArray(w * h); src.getPixels(p, 0, w, 0, 0, w, h)
                val q = IntArray(w * h)
                if (kind == 0) Bitmap.createScaledBitmap(Bitmap.createScaledBitmap(src, max(w / 20, 1), max(h / 20, 1), true), w, h, true).getPixels(q, 0, w, 0, 0, w, h) else q.fill(-1)
                for (y in 0 until h) { val my = y * mh / h
                    for (x in 0 until w) {
                        val a = ((conf[my * mw + x * mw / w] - .3f) / .4f).coerceIn(0f, 1f); val i = y * w + x; val f = p[i]; val g = q[i]
                        val r = (((f shr 16) and 255) * a + ((g shr 16) and 255) * (1 - a)).toInt(); val gg = (((f shr 8) and 255) * a + ((g shr 8) and 255) * (1 - a)).toInt(); val bb = ((f and 255) * a + (g and 255) * (1 - a)).toInt()
                        p[i] = (255 shl 24) or (r shl 16) or (gg shl 8) or bb
                    } }
                cb(Bitmap.createBitmap(p, w, h, Bitmap.Config.ARGB_8888))
            } catch (e: Throwable) { toast("Portrait failed: ${e.message}") }
        } }.addOnFailureListener { toast("Segmentation failed: ${it.message}") }
    }
    private fun bgEdit(m: Item, kind: Int) {
        toast("Segmenting…")
        bg.post { try { val b = decode(bytes(m.uri), 4_000_000L); segBlur(b, kind) { out -> save(out, m.name.substringBeforeLast('.') + (if (kind == 0) "_BGBLUR.jpg" else "_BGWHITE.jpg")); toast("Saved ✓"); refreshThumb() } } catch (e: Throwable) { toast("Failed: ${e.message}") } }
    }
    // ---------- OCR (Latin text; ML Kit has no Arabic model) ----------
    private fun ocr(m: Item) {
        toast("Reading text…")
        bg.post { try {
            val b = decode(bytes(m.uri), 8_000_000L)
            TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS).process(InputImage.fromBitmap(b, 0))
                .addOnSuccessListener { r -> ui.post { AlertDialog.Builder(this).setMessage(r.text.ifBlank { "No Latin text found" })
                    .setPositiveButton("COPY") { _, _ -> (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ocr", r.text)) }.setNegativeButton("CLOSE", null).show() } }
                .addOnFailureListener { toast("OCR failed: ${it.message}") }
        } catch (e: Throwable) { toast("OCR failed: ${e.message}") } }
    }
    // ---------- AI Eraser: paint, then fill from surrounding pixels (approximate, best for small objects) ----------
    private fun startErase(iv: ImageView) {
        val base = (iv.drawable as? android.graphics.drawable.BitmapDrawable)?.bitmap ?: return toast("Wait for the image to load")
        val work = base.copy(Bitmap.Config.ARGB_8888, true); val w = work.width; val h = work.height
        val mask = BooleanArray(w * h); val red = Paint().apply { color = Color.argb(140, 255, 40, 60) }; val cv = Canvas(work); val r = max(w / 40, 6)
        eBase = base; eMask = mask; iv.setImageBitmap(work); toast("Paint over the object, then tap APPLY ERASE")
        iv.setOnTouchListener { _, e ->
            val inv = Matrix(); iv.imageMatrix.invert(inv); val pt = floatArrayOf(e.x, e.y); inv.mapPoints(pt)
            cv.drawCircle(pt[0], pt[1], r.toFloat(), red)
            for (dy in -r..r) for (dx in -r..r) if (dx * dx + dy * dy <= r * r) { val xx = pt[0].toInt() + dx; val yy = pt[1].toInt() + dy; if (xx in 0 until w && yy in 0 until h) mask[yy * w + xx] = true }
            iv.invalidate(); true
        }
    }
    private fun applyErase(iv: ImageView, name: String) {
        val b = eBase; val mk = eMask; if (b == null || mk == null) { toast("Tap ERASE first"); return }
        iv.setOnTouchListener(null); toast("Erasing…"); eBase = null; eMask = null
        bg.post { try { val out = inpaint(b, mk); save(out, name.substringBeforeLast('.') + "_ERASE.jpg"); ui.post { iv.setImageBitmap(out); toast("Saved ✓ — approximate fill"); refreshThumb() } } catch (e: Throwable) { toast("Erase failed: ${e.message}") } }
    }
    private fun inpaint(src: Bitmap, mask: BooleanArray): Bitmap {
        val w = src.width; val h = src.height; val sc = max(1, max(w, h) / 900); val sw = max(w / sc, 1); val sh2 = max(h / sc, 1)
        val small = Bitmap.createScaledBitmap(src, sw, sh2, true); val p = IntArray(sw * sh2); small.getPixels(p, 0, sw, 0, 0, sw, sh2)
        val m = BooleanArray(sw * sh2) { mask[min((it / sw) * sc, h - 1) * w + min((it % sw) * sc, w - 1)] }
        val o = p.copyOf(); val dxs = intArrayOf(1, -1, 0, 0); val dys = intArrayOf(0, 0, 1, -1); val rr = 200
        for (y in 0 until sh2) for (x in 0 until sw) {
            val i = y * sw + x; if (!m[i]) continue
            var sr = 0f; var sg = 0f; var sb = 0f; var ws = 0f
            for (d in 0..3) {
                var xx = x; var yy = y; var k = 0; var hit = false
                while (k < rr) { xx += dxs[d]; yy += dys[d]; k++; if (xx < 0 || yy < 0 || xx >= sw || yy >= sh2) break; if (!m[yy * sw + xx]) { hit = true; break } }
                if (hit) { val c = p[yy * sw + xx]; val wg = 1f / (k * k); sr += ((c shr 16) and 255) * wg; sg += ((c shr 8) and 255) * wg; sb += (c and 255) * wg; ws += wg }
            }
            if (ws > 0f) o[i] = (255 shl 24) or ((sr / ws).toInt() shl 16) or ((sg / ws).toInt() shl 8) or (sb / ws).toInt()
        }
        val up = Bitmap.createScaledBitmap(Bitmap.createBitmap(o, sw, sh2, Bitmap.Config.ARGB_8888), w, h, true)
        val a = IntArray(w * h); src.getPixels(a, 0, w, 0, 0, w, h); val b = IntArray(w * h); up.getPixels(b, 0, w, 0, 0, w, h)
        for (i in a.indices) if (mask[i]) a[i] = b[i]
        return Bitmap.createBitmap(a, w, h, Bitmap.Config.ARGB_8888)
    }

    // ---------- color (live preview + saved photo use the same matrix) / Pro ----------
    private fun cmFor(mode: Int): ColorMatrix {
        val m = ColorMatrix(); m.setSaturation(floatArrayOf(1.2f, 1.5f, 1.25f, 1.25f)[mode])
        when (mode) {
            2 -> m.postConcat(ColorMatrix(floatArrayOf(1.08f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, .9f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
            3 -> m.postConcat(ColorMatrix(floatArrayOf(.92f, 0f, 0f, 0f, 0f, 0f, 1f, 0f, 0f, 0f, 0f, 0f, 1.08f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
        }
        val c = 1.12f; val o = 128f * (1f - c)
        m.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, o, 0f, c, 0f, 0f, o, 0f, 0f, c, 0f, o, 0f, 0f, 0f, 1f, 0f)))
        return m
    }
    private fun applyColor() {
        val on = colorMode != 0 || (cur == wide && cur != main)
        tv.setLayerType(if (on) View.LAYER_TYPE_HARDWARE else View.LAYER_TYPE_NONE, if (on) Paint().apply { colorFilter = ColorMatrixColorFilter(cmFor(colorMode)) } else null)
    }
    private fun tone(bm: Bitmap, mode: Int): Bitmap {
        val o = Bitmap.createBitmap(bm.width, bm.height, Bitmap.Config.ARGB_8888)
        Canvas(o).drawBitmap(bm, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cmFor(mode)) }); return o
    }
    private fun chroma(bm: Bitmap): Float {
        var s = 0f; var n = 0; val st = max(1, bm.width / 40); var y = 0
        while (y < bm.height) { var x = 0; while (x < bm.width) { val p = bm.getPixel(x, y); val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255; s += max(r, max(g, b)) - min(r, min(g, b)); n++; x += st }; y += st }
        return s / max(n, 1)
    }
    private fun applyManual(r: CaptureRequest.Builder, ch: CameraCharacteristics) {
        minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (pro) {
            val ir = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 800)
            val er = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(100_000L, 100_000_000L)
            r.set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            r.set(CaptureRequest.SENSOR_SENSITIVITY, iso.coerceIn(ir.lower, ir.upper)); r.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs.coerceIn(er.lower, er.upper))
        } else { val er = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE); if (er != null) r.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, ev.coerceIn(er.lower, er.upper)) }
        if (focusD >= 0f && minFocus > 0f) { r.set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF); r.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusD.coerceAtMost(minFocus)) }
    }
    private fun slider(name: String, mx: Int, init: Int, on: (Int) -> Unit) = LinearLayout(this).apply {
        gravity = Gravity.CENTER_VERTICAL
        addView(TextView(this@MainActivity).apply { text = name; setTextColor(Color.WHITE); textSize = 11f }, LinearLayout.LayoutParams(dp(72), -2))
        addView(SeekBar(this@MainActivity).apply {
            max = mx; progress = init
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar, p: Int, u: Boolean) { if (u) { on(p); push() } }
                override fun onStartTrackingTouch(s: SeekBar) {}
                override fun onStopTrackingTouch(s: SeekBar) {}
            })
        }, LinearLayout.LayoutParams(-1, -2))
    }
    private fun buildPro() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)); background = glass(dp(24).toFloat()); visibility = View.GONE
        addView(slider("ISO", 100, 10) { iso = 100 + it * 31 })
        addView(slider("SHUTTER", 100, 50) { expNs = (250_000.0 * 1000.0.pow(it / 100.0)).toLong() })
        addView(slider("EV (auto)", 12, 6) { ev = it - 6 })
        addView(slider("FOCUS", 100, 0) { focusD = if (it == 0) -1f else it / 100f * minFocus })
    }

    // ---------- real image processing ----------
    private fun decode(b: ByteArray, maxPx: Long): Bitmap {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }; BitmapFactory.decodeByteArray(b, 0, b.size, o)
        var ss = 1; while (o.outWidth.toLong() * o.outHeight / (ss * ss) > maxPx) ss *= 2
        val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = ss })
        val deg = when (ExifInterface(ByteArrayInputStream(b)).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        return if (deg == 0f) bm else Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, Matrix().apply { postRotate(deg) }, true)
    }
    // tone=true: gray-world white balance + percentile auto-contrast + gamma + saturation + sharpen. tone=false: sharpen only (used by upscale)
    private fun enhance(src: Bitmap, mono: Boolean, tone: Boolean): Bitmap {
        val w = src.width; val h = src.height; val n = w * h
        val p = IntArray(n); src.getPixels(p, 0, w, 0, 0, w, h)
        val o: IntArray
        if (tone) {
            var sr = 0L; var sg = 0L; var sb = 0L; var c = 0; var i = 0
            while (i < n) { val v = p[i]; sr += (v shr 16) and 255; sg += (v shr 8) and 255; sb += v and 255; c++; i += 7 }
            val mr = sr.toFloat() / c; val mg = sg.toFloat() / c; val mb = sb.toFloat() / c; val m = (mr + mg + mb) / 3f
            val gr = if (mono) 1f else (m / mr).coerceIn(.8f, 1.25f); val gg = if (mono) 1f else (m / mg).coerceIn(.8f, 1.25f); val gb = if (mono) 1f else (m / mb).coerceIn(.8f, 1.25f)
            val hist = IntArray(256); i = 0
            while (i < n) { val v = p[i]; hist[(.299f * ((v shr 16) and 255) * gr + .587f * ((v shr 8) and 255) * gg + .114f * (v and 255) * gb).toInt().coerceIn(0, 255)]++; i += 7 }
            val tot = hist.sum(); var acc = 0; var lo = 0; var hi = 255
            for (k in 0..255) { acc += hist[k]; if (acc >= tot * 0.005) { lo = k; break } }
            acc = 0; for (k in 0..255) { acc += hist[k]; if (acc >= tot * 0.995) { hi = k; break } }
            val sc = (255f / max(hi - lo, 64)).coerceAtMost(1.7f)
            val lut = IntArray(256) { (255.0 * (it / 255.0).pow(0.9)).toInt() }
            val sat = if (mono) 1f else 1.15f
            o = IntArray(n)
            for (k in 0 until n) {
                val v = p[k]
                var r = (((v shr 16) and 255) * gr - lo) * sc; var g = (((v shr 8) and 255) * gg - lo) * sc; var b = ((v and 255) * gb - lo) * sc
                val l = .299f * r + .587f * g + .114f * b
                r = l + (r - l) * sat; g = l + (g - l) * sat; b = l + (b - l) * sat
                o[k] = (255 shl 24) or (lut[r.toInt().coerceIn(0, 255)] shl 16) or (lut[g.toInt().coerceIn(0, 255)] shl 8) or lut[b.toInt().coerceIn(0, 255)]
            }
        } else o = p.copyOf()
        System.arraycopy(o, 0, p, 0, n)
        for (y in 1 until h - 1) { var k = y * w + 1
            for (x in 1 until w - 1) { p[k] = (255 shl 24) or (sh(o[k], o[k - 1], o[k + 1], o[k - w], o[k + w], 16) shl 16) or (sh(o[k], o[k - 1], o[k + 1], o[k - w], o[k + w], 8) shl 8) or sh(o[k], o[k - 1], o[k + 1], o[k - w], o[k + w], 0); k++ } }
        return Bitmap.createBitmap(p, w, h, Bitmap.Config.ARGB_8888)
    }
    private fun sh(c: Int, a: Int, b: Int, u: Int, d: Int, s: Int): Int {
        val x = (c shr s) and 255; val sum = ((a shr s) and 255) + ((b shr s) and 255) + ((u shr s) and 255) + ((d shr s) and 255)
        return (x + (.5f * (4 * x - sum)).toInt()).coerceIn(0, 255)
    }

    // ---------- Studio ----------
    private fun show(v: View) { overlay?.let { root.removeView(it) }; overlay = v; v.alpha = 0f; v.translationY = dp(30).toFloat(); root.addView(v, FrameLayout.LayoutParams(-1, -1)); v.animate().alpha(1f).translationY(0f).setDuration(260).start() }
    private fun hideOverlay() { val v = overlay ?: return; overlay = null; inViewer = false; v.animate().alpha(0f).translationY(dp(30).toFloat()).setDuration(200).withEndAction { root.removeView(v) }.start() }
    private fun openStudio() {
        inViewer = false; val cell = resources.displayMetrics.widthPixels / 3
        val grid = GridLayout(this).apply { columnCount = 3 }
        val sc = ScrollView(this).apply { addView(grid); setPadding(0, dp(96), 0, 0); clipToPadding = false }
        val head = TextView(this).apply { text = "STUDIO"; setTextColor(Color.WHITE); textSize = 20f; typeface = Typeface.DEFAULT_BOLD; setPadding(dp(20), dp(46), 0, 0) }
        val box = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(250, 6, 7, 12)); addView(sc); addView(head)
            addView(chip("CLOSE") { hideOverlay() }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END).apply { setMargins(0, dp(40), dp(16), 0) })
        }
        show(box)
        bg.post {
            val list = items()
            for (m in list) {
                val bm = try { contentResolver.loadThumbnail(m.uri, Size(320, 320), null) } catch (e: Exception) { null }
                ui.post {
                    val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setImageBitmap(bm); setBackgroundColor(Color.DKGRAY); setOnClickListener { openViewer(m, list) } }
                    val tag = TextView(this).apply { text = if (m.video) "▶ VIDEO" else if (m.name.contains("_AI")) "AI" else ""; setTextColor(Color.WHITE); textSize = 11f; setPadding(dp(6), 0, 0, dp(4)) }
                    val c = FrameLayout(this).apply { addView(iv); addView(tag, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.START)) }
                    grid.addView(c, GridLayout.LayoutParams().apply { width = cell - dp(2); height = cell - dp(2); setMargins(dp(1), dp(1), dp(1), dp(1)) })
                }
            }
        }
    }
    private fun openViewer(m: Item, all: List<Item>) {
        if (m.video) { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(m.uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)); return }
        inViewer = true
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        val band = View(this).apply { visibility = View.GONE; background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, Color.argb(170, 190, 225, 255), 0)) }
        val isAi = m.name.contains("_AI")
        val twin = if (isAi) all.firstOrNull { it.name == m.name.replace("_AI", "") } else all.firstOrNull { it.name == m.name.replace(".jpg", "_AI.jpg") }
        fun load(u: Uri, cb: (Bitmap?) -> Unit) { bg.post { val b = try { decode(bytes(u), 6_000_000L) } catch (e: Throwable) { null }; ui.post { cb(b) } } }
        if (isAi && twin != null) load(twin.uri) { o -> iv.setImageBitmap(o); load(m.uri) { a -> if (a != null) scan(iv, band, a) } } else load(m.uri) { iv.setImageBitmap(it) }
        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER }
        var alt = false
        if (twin != null) tools.addView(chip("ORIGINAL ⇄ AI") { alt = !alt; load(if (alt) twin.uri else m.uri) { b -> iv.setImageBitmap(b) } }, lp(3))
        tools.addView(chip("AI UPSCALE ×2") {
            toast("Upscaling…")
            bg.post { try {
                val b = decode(bytes(m.uri), 4_000_000L); val r = enhance(Bitmap.createScaledBitmap(b, b.width * 2, b.height * 2, true), false, false)
                val o = ByteArrayOutputStream(); r.compress(Bitmap.CompressFormat.JPEG, 95, o)
                insert(m.name.substringBeforeLast('.') + "_UP2.jpg", "image/jpeg", "Pictures/Aether") { s -> s.write(o.toByteArray()) }
                toast("Saved ×2 — new detail is interpolated, not real"); refreshThumb()
            } catch (e: Throwable) { toast("Upscale failed: ${e.message}") } }
        }, lp(3))
        tools.addView(chip("DELETE") { try { contentResolver.delete(m.uri, null, null) } catch (e: Exception) { toast("Delete blocked") }; refreshThumb(); openStudio() }, lp(3))
        tools.addView(chip("BACK") { openStudio() }, lp(3))
        tools.addView(chip("OCR") { ocr(m) }, lp(3)); tools.addView(chip("BG BLUR") { bgEdit(m, 0) }, lp(3)); tools.addView(chip("BG WHITE") { bgEdit(m, 1) }, lp(3))
        tools.addView(chip("ERASE") { startErase(iv) }, lp(3)); tools.addView(chip("APPLY ERASE") { applyErase(iv, m.name) }, lp(3))
        show(FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK); addView(iv); addView(band, FrameLayout.LayoutParams(-1, dp(120)))
            addView(HorizontalScrollView(this@MainActivity).apply { isHorizontalScrollBarEnabled = false; addView(tools) }, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(36) })
        })
    }
    private fun scan(iv: ImageView, band: View, after: Bitmap) {
        band.visibility = View.VISIBLE
        ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1300
            addUpdateListener { band.translationY = (iv.height - band.height) * (it.animatedValue as Float) }
            addListener(object : AnimatorListenerAdapter() { override fun onAnimationEnd(a: Animator) { band.visibility = View.GONE; iv.setImageBitmap(after) } })
        }.start()
    }
}
